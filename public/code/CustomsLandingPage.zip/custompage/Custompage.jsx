import React, { useState } from "react";
import { FaHome, FaUserCog, FaCog } from "react-icons/fa";
import { MdSensors } from "react-icons/md";
import "./Prototype.css";
import clientlogo from "./clientlogo.png";
import "./analytics.css";
import ing from "./resoluteai.png";
import adminlogo from "./adminlogo.png";

const Facegenie = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  const toggleSidebar = () => setSidebarOpen(!isSidebarOpen);

  return (
    <div className="app-container">
      <div className={`sidebar ${isSidebarOpen ? "open" : "closed"}`}>
        <div className="logo">
          <img src={ing} alt="ResoluteAi Logo" />
        </div>

        <nav className="nav-links">
          <button className="nav-button">
            <FaHome />
            <span>Home</span>
          </button>

          <button className="nav-button">
            <MdSensors />
            <span>Sensor's Health</span>
          </button>

          <button className="nav-button">
            <FaCog />
            <span>Configuration</span>
          </button>

          <button className="nav-button">
            <FaUserCog />
            <span>User Management</span>
          </button>
        </nav>
      </div>
      <div className="main-content">
        <header className="app-header">
          <button className="sidebar-toggle" onClick={toggleSidebar}>
            <div className="toggle-icon"></div>
          </button>
          <div className="hamburger-hover-wrapper">
            <button className="hamburger-toggle">
              <div className="bar"></div>
              <div className="bar"></div>
              <div className="bar"></div>
            </button>

            <div className="hover-nav-card">
              <button className="nav-button">
                <FaHome /> <span>Home</span>
              </button>
              <button className="nav-button">
                <MdSensors /> <span>Sensor's Health</span>
              </button>
              <button className="nav-button">
                <FaCog /> <span>Configuration</span>
              </button>
              <button className="nav-button">
                <FaUserCog /> <span>User Management</span>
              </button>
            </div>
          </div>
          <h1>Title of the Application</h1>
          <div className="app-client">
            <img src={clientlogo} alt="Client Logo" />
          </div>
          <div className="app-logo">
            <img src={adminlogo} alt="Client Logo" />
          </div>
        </header>
        <div className="content-body">
          <h2 className="dash-workspace-title">Work Space</h2>
          <div className="download-actions"></div>
        </div>
      </div>
    </div>
  );
};

export default Facegenie;
