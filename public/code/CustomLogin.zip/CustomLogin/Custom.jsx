import React from "react";

import "./MainTemplate.css";

import logo from "./resoluteai.png";
import ClientLogo from './clientlogo.png'

const Custom = () => {
  return (
    <div className="main-template-container">
      <div className="template-content-box">
        <h4>{"Client's Products and Images"}</h4>
      </div>

      <div className="template-login-box">
        <div
          className="template-logo"
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          
          <img 
            src={ClientLogo} 
            alt="Client logo" 
            className="template-dash" 
            style={{
              marginTop: '20px',
              width: "100px",
              height: "auto",
              maxHeight: "50px",
              objectFit: "contain"
            }} 
          />
        </div>

        <form className="template-form">
          <label>Email Id</label>
          <input type="email" placeholder="you@example.com" />
          <label>Password</label>
          <input type="password" placeholder="Enter Your Password" />
          <button type="submit">Sign In</button>
        </form>

        <div className="template-powered-by">
          <p
            className="powered"
            style={{
              fontSize: "14px",
              fontWeight: "bold",
              marginBottom: "2px",
            }}
          >
            Powered By
          </p>
          <img src={logo} alt="ResoluteAI Software" className="template-dash" />
        </div>
      </div>
    </div>
  );
};

export default Custom;
