import React from "react";

import "./MainTemplate.css";

import logo from "./resoluteai.png";

const ProMain = () => {
  return (
    <div className="main-template-container">
      <div className="template-content-box">
        <h4>{"Landing Screen"}</h4>
      </div>

      <div className="template-login-box">
        <div
          className="template-logo"
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          {/* USE PRODUCT TITLE OR PRODUCT LOGO */}
          <h5
            style={{
              marginTop: "30px",
              fontSize: "25px",
              color: "red",
              // border: '2px solid red',
              //  padding:'20px 20px'
            }}
          >
            {" "}
            Product Title
          </h5>
          {/* <img 
            src={productLogo} 
            alt="productLogo" 
            className="template-dash" 
            style={{
              marginTop: '20px',
              width: "100px",
              height: "auto",
              maxHeight: "50px",
              objectFit: "contain"
            }} 
          /> */}
        </div>

        <form className="template-form">
          <label>Email Id</label>
          <input type="email" placeholder="you@example.com" />
          <label>Password</label>
          <input type="password" placeholder="Enter Your Password" />
          <button type="submit">Sign In</button>
        </form>

        <div className="template-powered-by">
          <p
            className="powered"
            style={{
              fontSize: "14px",
              fontWeight: "bold",
              marginBottom: "2px",
            }}
          >
            Powered By
          </p>
          <img src={logo} alt="ResoluteAI Software" className="template-dash" />
        </div>
      </div>
    </div>
  );
};

export default ProMain;
